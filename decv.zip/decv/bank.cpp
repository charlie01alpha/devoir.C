#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <ctime>
using namespace std;

class Transaction {
public:
    string date;
    string description;
    double montant;

    Transaction(const string& desc, double mont) : description(desc), montant(mont) {
        time_t now = time(0);
        date = ctime(&now);
    }
};

class CompteBancaire {
private:
    string numeroCompte;
    string nomClient;
    double solde;
    bool verrouille;
    vector<Transaction> transactions;

public:
    CompteBancaire(string num, string nom, double sol)
        : numeroCompte(num), nomClient(nom), solde(sol), verrouille(false) {}

    string getNumeroCompte() const { return numeroCompte; }
    string getNomClient() const { return nomClient; }
    double getSolde() const { return solde; }
    bool estVerrouille() const { return verrouille; }

    void verrouiller() { verrouille = true; }
    void debloquer() { verrouille = false; }

    void deposer(double montant) {
        if (verrouille) {
            cout << "Le compte est verrouiller. Impossible de realiser l'operation." << endl;
            return;
        }
        solde += montant;
        transactions.push_back(Transaction("Depot", montant));
    }

    void retirer(double montant) {
        if (verrouille) {
            cout << "Le compte est verrouillé. Impossible de réaliser l'opération." << endl;
            return;
        }
        if (montant > solde) {
            cout << "Fonds insuffisants pour effectuer ce retrait." << endl;
            return;
        }
        solde -= montant;
        transactions.push_back(Transaction("Retrait", -montant));
    }

    void transferer(CompteBancaire& autreCompte, double montant) {
        if (verrouille) {
            cout << "Le compte est verrouiller. Impossible de réaliser l'opération." << endl;
            return;
        }
        if (montant > solde) {
            cout << "Fonds insuffisants pour effectuer ce transfert." << endl;
            return;
        }
        solde -= montant;
        autreCompte.deposer(montant);
        transactions.push_back(Transaction("Transfert vers " + autreCompte.getNumeroCompte(), -montant));
        autreCompte.transactions.push_back(Transaction("Transfert depuis " + numeroCompte, montant));
    }

    void afficherReleve() const {
        cout << "Releve des transactions pour le compte " << numeroCompte << " (Client: " << nomClient << "):" << endl;
        for (const auto& trans : transactions) {
            cout << trans.date << " - " << trans.description << ": " << trans.montant << " FCFA" << endl;
        }
        cout << "Solde actuel: " << solde << " FCFA" << endl;
    }

    static CompteBancaire* chercherCompte(vector<CompteBancaire>& comptes, const string& numero) {
        for (auto& compte : comptes) {
            if (compte.getNumeroCompte() == numero) {
                return &compte;
            }
        }
        return nullptr;
    }

    static CompteBancaire* chercherCompteParNom(vector<CompteBancaire>& comptes, const string& nom) {
        for (auto& compte : comptes) {
            if (compte.getNomClient() == nom) {
                return &compte;
            }
        }
        return nullptr;
    }
};

void sauvegarderComptes(const vector<CompteBancaire>& comptes, const string& filename) {
    ofstream fichier(filename);
    if (!fichier) {
        cout << "Erreur d'ouverture du fichier!" << endl;
        return;
    }
    for (const auto& compte : comptes) {
        fichier << compte.getNumeroCompte() << " "
                << compte.getNomClient() << " "
                << compte.getSolde() << " "
                << compte.estVerrouille() << endl;
    }
    fichier.close();
}

void chargerComptes(vector<CompteBancaire>& comptes, const string& filename) {
    ifstream fichier(filename);
    if (!fichier) {
        cout << "Fichier non trouver, aucun compte charger." << endl;
        return;
    }
    string numCompte, nomClient;
    double solde;
    bool verrouille;
    while (fichier >> numCompte >> nomClient >> solde >> verrouille) {
        CompteBancaire compte(numCompte, nomClient, solde);
        if (verrouille) {
            compte.verrouiller();
        }
        comptes.push_back(compte);
    }
    fichier.close();
}

int main() {
    vector<CompteBancaire> comptes;
    chargerComptes(comptes, "comptes.txt");

    int choix;
    do {
        cout << "\n1. Creer un compte\n2. Deposer\n3. Retirer\n4. Transferer\n5. Afficher releve\n6. Verrouiller un compte\n7. Debloquer un compte\n8. Chercher un compte\n9. Sauvegarder et quitter\n";
        cout << "Entrez votre choix: ";
        cin >> choix;

        if (choix == 1) {
            string numCompte, nomClient;
            double soldeInitial;
            cout << "Numero du compte: ";
            cin >> numCompte;
            cout << "Nom du client: ";
            cin >> nomClient;
            cout << "Solde initial: ";
            cin >> soldeInitial;
            comptes.push_back(CompteBancaire(numCompte, nomClient, soldeInitial));
        }
        else if (choix == 2) {
            string numCompte;
            double montant;
            cout << "Numero du compte: ";
            cin >> numCompte;
            cout << "Montant a deposer: ";
            cin >> montant;

            CompteBancaire* compte = CompteBancaire::chercherCompte(comptes, numCompte);
            if (compte) {
                compte->deposer(montant);
            } else {
                cout << "Compte non trouve!" << endl;
            }
        }
        else if (choix == 3) {
            string numCompte;
            double montant;
            cout << "Numero du compte: ";
            cin >> numCompte;
            cout << "Montant a retirer: ";
            cin >> montant;

            CompteBancaire* compte = CompteBancaire::chercherCompte(comptes, numCompte);
            if (compte) {
                compte->retirer(montant);
            } else {
                cout << "Compte non trouve!" << endl;
            }
        }
        else if (choix == 4) {
            string numCompte1, numCompte2;
            double montant;
            cout << "Numero du compte source: ";
            cin >> numCompte1;
            cout << "Numero du compte destination: ";
            cin >> numCompte2;
            cout << "Montant a transferer: ";
            cin >> montant;

            CompteBancaire* compteSource = CompteBancaire::chercherCompte(comptes, numCompte1);
            CompteBancaire* compteDest = CompteBancaire::chercherCompte(comptes, numCompte2);
            if (compteSource && compteDest) {
                compteSource->transferer(*compteDest, montant);
            } else {
                cout << "Compte(s) non trouve(s)!" << endl;
            }
        }
        else if (choix == 5) {
            string numCompte;
            cout << "Numero du compte: ";
            cin >> numCompte;

            CompteBancaire* compte = CompteBancaire::chercherCompte(comptes, numCompte);
            if (compte) {
                compte->afficherReleve();
            } else {
                cout << "Compte non trouve!" << endl;
            }
        }
        else if (choix == 6) {
            string numCompte;
            cout << "Numero du compte a verrouiller: ";
            cin >> numCompte;

            CompteBancaire* compte = CompteBancaire::chercherCompte(comptes, numCompte);
            if (compte) {
                compte->verrouiller();
                cout << "Compte verrouiller." << endl;
            } else {
                cout << "Compte non trouver!" << endl;
            }
        }
        else if (choix == 7) {
            string numCompte;
            cout << "Numero du compte a debloquer: ";
            cin >> numCompte;

            CompteBancaire* compte = CompteBancaire::chercherCompte(comptes, numCompte);
            if (compte) {
                compte->debloquer();
                cout << "Compte debloquer." << endl;
            } else {
                cout << "Compte non trouver!" << endl;
            }
        }
        else if (choix == 8) {
            string recherche;
            cout << "Rechercher par (numero/nom): ";
            cin >> recherche;

            CompteBancaire* compte = CompteBancaire::chercherCompte(comptes, recherche);
            if (compte) {
                cout << "Compte trouver: " << compte->getNumeroCompte() << " - " << compte->getNomClient() << endl;
            } else {
                cout << "Compte non trouver!" << endl;
            }
        }

    } while (choix != 9);

    sauvegarderComptes(comptes, "comptes.txt");
    cout << "Données sauvegardees. Au revoir!" << endl;

    return 0;
}
